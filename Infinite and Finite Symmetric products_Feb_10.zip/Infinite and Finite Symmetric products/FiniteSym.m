LexOrder[m_, k_] := Module[{ur, i, j, l}, 
     ur = {}; If[k == 1, ur = Table[{j}, {j, 1, m}]]; 
      If[k > 1, l = {}; ur = Flatten[Table[{i, j}, {i, 1, m}, {j, i, m}]]; 
        ur = Table[{ur[[2*i - 1]], ur[[2*i]]}, {i, 1, Length[ur]/2}]; 
        While[Length[ur[[1]]] < k, For[j = 1, j <= m, j++, 
           For[i = 1, i <= Length[ur], i++, If[ur[[i]][[1]] >= j, 
               l = Append[l, Prepend[ur[[i]], j]]; ]; ]; ]; ur = l; 
          l = {}; ]; ]; Return[ur]; ]
 
ProdSym[A_, B_, n_, k1_, k2_] := Module[{o1, o2, O1, O2, AA, BB, c, i, o3, 
      O3, j, vars, cc, e}, If[k1 == 0, If[Depth[A] == 1, Return[A*B]; ]; 
        If[Depth[A] == 2, If[Length[A] == 1, Return[A[[1]]*B]; ]; 
          If[Length[A] > 1, Print["Error 1"]; Return[0]; ]; ]; 
        If[Depth[A] > 2, Print["Error 2"]; Return[0]; ]; ]; 
      If[k2 == 0, If[Depth[B] == 1, Return[A*B]; ]; If[Depth[B] == 2, 
         If[Length[B] == 1, Return[A*B[[1]]]; ]; If[Length[B] > 1, 
           Print["Error 1"]; Return[0]; ]; ]; If[Depth[B] > 2, 
         Print["Error 2"]; Return[0]; ]; ]; o1 = LexOrder[n, k1]; 
      O1 = Table[Product[e[o1[[i]][[j]]], {j, 1, k1}], {i, 1, Length[o1]}]; 
      o2 = LexOrder[n, k2]; O2 = Table[Product[e[o2[[i]][[j]]], {j, 1, k2}], 
        {i, 1, Length[o2]}]; AA = A . O1; BB = B . O2; 
      o3 = LexOrder[n, k1 + k2]; O3 = Table[Product[e[o3[[i]][[j]]], 
         {j, 1, k1 + k2}], {i, 1, Length[o3]}]; 
      vars = Table[e[i], {i, 1, n}]; c = Expand[AA*BB]; 
      cc = Table[PolynomialReduce[c, O3[[j]], vars][[1]][[1]], 
        {j, 1, Length[o3]}]; Return[cc]; ]
 
d[n_, k_] := Binomial[n + k - 1, n - 1]
 
dd[n_, k_] := Sum[d[n, j], {j, 1, k}]
 
Binom[list1_, list2_] := Product[list1[[i]]!, {i, 1, Length[list1]}]/
     (Product[list2[[i]]!, {i, 1, Length[list2]}]*
      Product[(list1 - list2)[[i]]!, {i, 1, Length[list1]}])
 
sumforSym[jk_, n_] := Module[{m, ii, M, i}, ii = Table[1, {i, 1, n}]; m = {}; 
      M = Tuples[Table[i, {i, 0, jk}], n]; For[i = 1, i <= Length[M], i++, 
       If[M[[i]] . ii == jk, m = Append[m, M[[i]]]; ]; ]; 
      Return[Reverse[DeleteDuplicates[m]]]; ]
 
smaller[beta_, alpha_] := Module[{i}, If[Length[alpha] != Length[beta], 
       Return[-1]; ]; For[i = 1, i <= Length[alpha], i++, 
       If[beta[[i]] > alpha[[i]], Return[1]; ]; ]; Return[0]; ]
 
transpose[A_] := Module[{}, If[Depth[A] == 1, Return[A]; ]; 
      If[Depth[A] == 2, If[Length[A] == 1, Return[A]; ]; 
        If[Length[A] > 1, Return[Transpose[Partition[A, 1]]]; ]; ]; 
      If[Depth[A] >= 3, Return[Transpose[A]]; ]; ]
 
ProdSymMatfinal[AA_, BB_, n_] := Module[{A, B, C1, r1, r2, c1, c2, k1, k2, 
      j1, j2}, A = AA; B = BB; r1 = Length[A]; r2 = Length[B]; 
      c1 = Length[A[[1]]]; If[c1 == 0, c1++; ]; c2 = Length[B[[1]]]; 
      If[c2 == 0, c2++; ]; k1 = BinomialSolve[n, r1]; 
      If[k1 == -1, Print["Wrong number of rows for A"]; Return[0]; ]; 
      k2 = BinomialSolve[n, r2]; If[k2 == -1, 
       Print["Wrong number of rows for B"]; Return[0]; ]; 
      j1 = BinomialSolve[n, c1]; If[j1 == -1, 
       Print["Wrong number of columns for A"]; Return[0]; ]; 
      j2 = BinomialSolve[n, c2]; If[j2 == -1, 
       Print["Wrong number of columns for B"]; Return[0]; ]; 
      C1 = ProdSymMat[A, B, n, k1, k2, j1, j2]; 
      If[StringCount[ToString[C1], "{"] == 1, C1 = Partition[C1, 1]; ]; 
      Return[C1]; ]
 
BinomialSolve[n_, r_] := Module[{sol, kvar}, 
     sol = Solve[d[n, kvar] == r && kvar >= 0, kvar, Integers]; 
      If[sol == {}, Return[-1]; ]; Return[kvar /. sol[[1]]]; ]
 
ProdSymMat[A_, B_, n_, i1_, i2_, j1_, j2_] := 
    Module[{AT, BT, CT, plist, qlist, jlist, ilist, CTi, Kple, pple, p, q, 
      vec1, vec2, i}, AT = transpose[A]; BT = transpose[B]; 
      plist = sumforSym[j1, n]; qlist = sumforSym[j2, n]; 
      jlist = sumforSym[j1 + j2, n]; ilist = sumforSym[i1 + i2, n]; CT = {}; 
      For[i = 1, i <= Length[jlist], i++, 
       CTi = Table[0, {j, 1, Length[ilist]}]; Kple = jlist[[i]]; 
        For[p = 1, p <= Length[plist], p++, pple = plist[[p]]; 
          If[smaller[pple, Kple] == 0, q = Flatten[Position[qlist, 
                Kple - pple]][[1]]; vec1 = AT[[p]]; vec2 = BT[[q]]; 
            CTi = CTi + Binom[Kple, pple]*ProdSym[vec1, vec2, n, i1, 
                i2]; ]; ]; CT = Append[CT, CTi]; ]; 
      Return[(1/Binomial[j1 + j2, j1])*Transpose[CT]]; ]
 
Sym[A_, B_, n_] := Module[{AA, BB, AAA, BBB, CC, ra, ca, rb, cb}, 
     AA = A; If[StringCount[ToString[AA], "{"] == 1, 
       AA = Partition[AA, 1]; ]; ra = Length[AA]; ca = Length[AA[[1]]]; 
      AAA = Table[ToExpression[StringJoin[ToString[samplea], 
          ToString[ca*i + j]]], {i, 0, ra - 1}, {j, 0, ca - 1}]; BB = B; 
      If[StringCount[ToString[BB], "{"] == 1, BB = Partition[BB, 1]; ]; 
      rb = Length[BB]; cb = Length[BB[[1]]]; 
      BBB = Table[ToExpression[StringJoin[ToString[sampleb], 
          ToString[cb*i + j]]], {i, 0, rb - 1}, {j, 0, cb - 1}]; 
      CC = ProdSymMatfinal[AAA, BBB, n]; Return[CC /. MatrixSubs[AAA, AA] /. 
        MatrixSubs[BBB, BB]]; ]
 
MatrixSubs[A_, B_] := Module[{}, If[Dims[A] != Dims[B], 
       Print["Error: the dimensions do not add up during substitution"]; ]; 
      Return[Flatten[Table[A[[i]][[j]] -> B[[i]][[j]], {i, 1, Length[A]}, 
         {j, 1, Length[A[[1]]]}]]]; ]
 
Dims[A_] := {Length[A], Length[A[[1]]]}
